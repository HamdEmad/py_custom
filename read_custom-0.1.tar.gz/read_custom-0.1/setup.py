from setuptools import setup, find_packages
setup(
    name='read_custom',
    version='0.1',
    py_modules=['read_custom'],
    # Add any other metadata or dependencies needed
)
