import pandas as pd
import fitz
from concurrent.futures import ThreadPoolExecutor
import requests
import io 
#--------------------------------------------------------------------------------------------------------------------------
def read_txt(x):
    return pd.read_csv(x, dtype=str, keep_default_na=False, na_values=[''], encoding="ISO-8859-1", sep='\t')
#--------------------------------------------------------------------------------------------------------------------------
def read_csv(x):
    return pd.read_csv(x, dtype=str, keep_default_na=False, na_values=[''], encoding="ISO-8859-1")
#--------------------------------------------------------------------------------------------------------------------------
def read_xlsx(x):
    return pd.read_excel(x, dtype=str, keep_default_na=False, na_values=[''])
#--------------------------------------------------------------------------------------------------------------------------
def fitz_line(pdfs):
    line_data={}
    head={
        'User-Agent':"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/119.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5"}
    def parse_pdf(pdf):  
        try:
            url = pdf.replace('http://download.siliconexpert.com', r'\\10.199.104.50').replace('/', '\\')
            with open(url, 'rb') as f:
                content = f.read() 
        except :
            try:
                response = requests.get(pdf, timeout=15, headers= head)  
                content = io.BytesIO(response.content)
            except : 
                None
        try:
            with fitz.open(stream=content) as file:
                words = [page.get_text_words()  for page in file.pages()]
                page_lines=[]
                for page in words:
                    wordsss= {}
                    for i in page:
                        line= int(i[3])   
                        if line in wordsss:
                            wordsss[line].append(i[4])     
                        elif line+1 in wordsss: 
                            wordsss[line+1].append(i[4]) 
                        elif line-1 in wordsss:
                            wordsss[line-1].append(i[4])   
                        elif line+2 in wordsss: 
                            wordsss[line+2].append(i[4])
                        elif line-2 in wordsss: 
                            wordsss[line-2].append(i[4])
                        else:
                            wordsss[line]= [i[4]]         
                     #inside loop for words and the outer for line       
                    page_lines.append( '\n'.join({i:" ".join(k) for i,k in sorted(wordsss.items())}.values()) )
                line_data[pdf]= '\n'.join(page_lines) #this concatenat pages   
        except :
            None
    with ThreadPoolExecutor() as executor:
        executor.map(parse_pdf, pdfs)
    return line_data
#--------------------------------------------------------------------------------------------------------------------------
def fitz_defult(pdfs):
    head={
        'User-Agent':"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/119.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5"}
    pdf_data={}
    def parse_pdf(pdf):
        try:
            url = pdf.replace('http://download.siliconexpert.com', r'\\10.199.104.50').replace('/', '\\')
            with open(url, 'rb') as f:
                content = f.read() 
        except:
            try:
                response = requests.get(pdf, timeout=15, headers= head)  
                content = io.BytesIO(response.content)
            except:
                None
        try:
            with fitz.open(stream=content) as file:
                rows = ' '.join([page.get_text()  for page in file.pages()])
                pdf_data[pdf]= rows
        except:
            None
    with ThreadPoolExecutor() as executor:
        results = executor.map(parse_pdf, pdfs)
    return pdf_data
#--------------------------------------------------------------------------------------------------------------------------
